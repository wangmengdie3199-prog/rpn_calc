#!/bin/bash
echo "正在启动RPN计算器..."
chmod +x rpn_calc
./rpn_calc
